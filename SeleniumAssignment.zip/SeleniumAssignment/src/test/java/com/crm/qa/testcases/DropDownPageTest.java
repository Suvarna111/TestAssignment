/*
 * @author Naveen Khunteta
 * 
 */

package com.crm.qa.testcases;

import java.io.IOException;

import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.DropDownPage;
import com.crm.qa.util.TestUtil;

public class DropDownPageTest extends TestBase{

	TestUtil testUtil;
	DropDownPage dropDownPage;
	   
	public DropDownPageTest(){
			super();
			
	}
	
	
	@BeforeClass
	public void setUp() throws InterruptedException {
		
		initialization();
		testUtil = new TestUtil();
		dropDownPage = new DropDownPage();
		//TestUtil.runTimeInfo("error", "Page load successful");
		//testUtil.switchToFrame();		
	}
	

	@Test(priority=1)
	public void verifyAndSelectDropDownOption(){
		Assert.assertTrue(dropDownPage.verifyDropDownLink(), "Drop down link is missing on the page");
		dropDownPage.clickOnDropDownLink();
		Assert.assertTrue(dropDownPage.verifyDropDownBox(), "Drop down box is missing on the page");
		dropDownPage.selectItemsByName("India");
	}
	
	@AfterClass
	public void tearDown(){
		driver.quit();
	}
	
	
	
	
}
