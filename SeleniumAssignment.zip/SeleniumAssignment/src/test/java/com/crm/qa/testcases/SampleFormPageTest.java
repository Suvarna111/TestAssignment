/*
 * @author Suvarna Bodkhe
 * 
 */

package com.crm.qa.testcases;

import java.io.IOException;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.DragAndDropPage;
import com.crm.qa.pages.SampleFormPage;
import com.crm.qa.util.TestUtil;

public class SampleFormPageTest extends TestBase{

	TestUtil testUtil;
	SampleFormPage sampleFormPage;
	
	String sheetName = "sampleForm";
	
	   
	public SampleFormPageTest(){
			super();
			
	}
	
	
	@BeforeMethod
	public void setUp() throws InterruptedException {
		
		initialization();
		testUtil = new TestUtil();
		sampleFormPage = new SampleFormPage();
	//	TestUtil.runTimeInfo("error", "Page load successful");
	}
	
	@Test(priority=1, dataProvider="getExcelTestData")
	public void verifyAndAddDetails(String name,String userEmailId, String webUrl,String experienceInput,String comment){
		Assert.assertTrue(sampleFormPage.verifySampleFormPageLink(), "Sample form Page link is missing on the page");
		sampleFormPage.clickOnSampleFormPageLink();
		
		
		sampleFormPage.addSampleFormDetails(name, userEmailId, webUrl, experienceInput, comment);
		//testUtil.getJsonTestData("sampleForm");
		//sampleFormPage.addSampleFormDetails();
		}
	
	@DataProvider
	public Object[][] getExcelTestData(){
		Object data[][] = TestUtil.getTestData(sheetName);
		return data;
	}
	

	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
	
	
	
}
