/*
 * @author Suvarna Bodkhe
 * 
 */

package com.crm.qa.testcases;

import java.io.File;
import java.nio.file.Files;
import org.json.simple.JSONObject;
import java.io.IOException;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.DragAndDropPage;
import com.crm.qa.pages.SampleFormPage;
import com.crm.qa.util.TestUtil;
import com.jayway.jsonpath.JsonPath;

public class SampleFormPageTestJson extends TestBase{

	TestUtil testUtil;
	SampleFormPage sampleFormPage;
	String sheetName = "sampleForm";
	static String json;
	JSONObject UserDetails;
	public static String name, userEmailId, webUrl, experienceInput, comment;
	public File file = null;
	
	   
	public SampleFormPageTestJson(){
			super();
			
	}
	
	
	@BeforeMethod
	public void setUp() throws InterruptedException {
		
		initialization();
		testUtil = new TestUtil();
		sampleFormPage = new SampleFormPage();
	//	TestUtil.runTimeInfo("error", "Page load successful");
	}
	
	@Test(priority=1)
	
	public void verifyAndAddDetails(String name,String userEmailId, String webUrl,String experienceInput,String comment) throws Exception{
		
		Assert.assertTrue(sampleFormPage.verifySampleFormPageLink(), "Sample form Page link is missing on the page");
		sampleFormPage.clickOnSampleFormPageLink();
		
		
		try {
		
			String dataFileName = "C:\\Users\\singh\\eclipseWorksapce\\Gayathri\\TestNG\\SeleniumAssignment\\src\\main\\java\\com\\crm\\qa\\testdata\\Userdata.json";
			file = new File(dataFileName);
			json = new String (Files.readAllBytes(file.toPath()));
			name = JsonPath.read(json, "$.validUser.name");
			userEmailId = JsonPath.read(json, "$.validUser.userEmailId");
			webUrl = JsonPath.read(json, "$.validUser.webUrl");
			experienceInput = JsonPath.read(json, "$.validUser.experienceInput");
			comment = JsonPath.read(json, "$.validUser.comment");
			
		sampleFormPage.addSampleFormDetails(name, userEmailId, webUrl, experienceInput, comment);
		//testUtil.getJsonTestData("sampleForm");
		//sampleFormPage.addSampleFormDetails();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}
	
	@DataProvider
	public Object[][] getExcelTestData(){
		Object data[][] = TestUtil.getTestData(sheetName);
		return data;
	}
	

	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
	
	
	
	
}
