/*
 * @author Suvarna Bodkhe
 * 
 */

package com.crm.qa.testcases;

import java.io.IOException;

import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.DragAndDropPage;
import com.crm.qa.util.TestUtil;

public class DragAndDropPageTest extends TestBase{

	TestUtil testUtil;
	DragAndDropPage dragAndDropPage;
	  
	public DragAndDropPageTest(){
			super();
			
	}
	
	
	@BeforeClass
	public void setUp() throws InterruptedException {
		
		initialization();
		testUtil = new TestUtil();
		dragAndDropPage = new DragAndDropPage();
	}
	
	@Test(priority=1)
	public void verifyDragAndDrop(){
		Assert.assertTrue(dragAndDropPage.verifyDragAndDropLink(), "Drag and drop link is missing on the page");
		dragAndDropPage.clickOnDragAndDropLink();
		Assert.assertTrue(dragAndDropPage.verifyDragAndDropPageHeader(), "Drag and drop header is missing on the page");
		//dragAndDropPage.dragAndDrop();
		//Assert.assertTrue(dragAndDropPage.isDragAndDropped(), "Item is dragged and dropped successfully");
	   System.out.print("Drag and drop activity done successfully..!!");
	}
	

	@AfterClass
	public void tearDown(){
		driver.quit();
	}
	
	
	
	
}
