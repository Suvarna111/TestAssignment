package com.crm.qa.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.crm.qa.base.TestBase;

public class SampleFormPage extends TestBase{

	
	@FindBy(xpath = "//div[@class='price_column price_column_featured']//a[@href='https://www.globalsqa.com/samplepagetest/']")
	WebElement sampleFormPageLink;
	
	@FindBy(xpath="//input[@type='text'][@class='name']")
	WebElement userName;
	
	@FindBy(xpath="//input[@type='email'][@class='email']")
	WebElement emailId;
	
	@FindBy(xpath="//input[@type='url'][@class='url']")
	WebElement website;
	
	@FindBy(xpath="//div[@class='grunion-field-wrap grunion-field-select-wrap']//select")
	WebElement experienceDropdown;
	
	@FindBy(xpath="//div[@class='grunion-field-wrap grunion-field-textarea-wrap']//textarea[@class='textarea']")
	WebElement commentTxt;
	

	@FindBy(xpath="//button[@type='submit']")
	WebElement submitBtn;
	
	// Initializing the Page Objects:
		public SampleFormPage() {
			PageFactory.initElements(driver, this);
		}
		
		public void scrollIntoViewPage(WebElement element)
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", element);
		}

		public void scrollDown()
		{
			Actions a = new Actions(driver);
			//scroll up a page
			a.sendKeys(Keys.PAGE_DOWN).build().perform();
		}
		
		public void scrollUp()
		{
			Actions a = new Actions(driver);
			//scroll up a page
			a.sendKeys(Keys.PAGE_UP).build().perform();
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		}
		
	    public boolean verifySampleFormPageLink(){
	    	//scrollUp();
		     if(sampleFormPageLink.isDisplayed())
		       {
		         return sampleFormPageLink.isDisplayed();
		       }
		     else
		       {
			     driver.navigate().refresh();
			     driver.manage().timeouts().implicitlyWait(7,TimeUnit.SECONDS);
		        }
		      return sampleFormPageLink.isDisplayed();
     	}
	
	    public void clickOnSampleFormPageLink()
	   {
		  sampleFormPageLink.click();
	   }
	
	public void addSampleFormDetails(String name,String userEmailId, String webUrl,String experienceInput,String comment){
		//scrollDown();
		userName.sendKeys(name);
		emailId.sendKeys(Keys.TAB);
		emailId.sendKeys(userEmailId);
		website.sendKeys(webUrl);
		Select objSelect =new Select(driver.findElement(By.tagName("select")));
		objSelect.selectByValue(experienceInput);	
		commentTxt.sendKeys(comment);
		submitBtn.click();
	}

}

