package com.crm.qa.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.qa.base.TestBase;

public class DragAndDropPage extends TestBase{

	
	@FindBy(xpath = "//li[@class='price_footer']//a[text()='DragAndDrop']")
	WebElement dragAndDropLink;
	
	@FindBy(xpath = "//h1[text()='Drag And Drop']")
	WebElement dragAndDropHeader;
	
	@FindBy(xpath = "//h5[text()='High Tatras']")
	WebElement dragAndDropfrom;
	
	
	@FindBy(xpath = "//div[@id='trash']")
	WebElement dragAndDropTo;
	
	
	@FindBy(xpath = "//ul[@class='gallery ui-helper-reset']")
	WebElement postDragAndDrop;
	
	
	// Initializing the Page Objects:
		public DragAndDropPage() {
			PageFactory.initElements(driver, this);
		}

		public void ScrollIntoViewPage(WebElement element)
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", element);
		}
		
		public boolean verifyDragAndDropLink(){
			ScrollIntoViewPage(dragAndDropLink);
			if(dragAndDropLink.isDisplayed())
			{
			return dragAndDropLink.isDisplayed();
			}
			else
			{
				driver.navigate().refresh();
				driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
			}
			return dragAndDropLink.isDisplayed();
		}
		
		public void clickOnDragAndDropLink()
		{
			dragAndDropLink.click();
		}
		 
		public boolean verifyDragAndDropPageHeader(){
			return dragAndDropHeader.isDisplayed();
		}
		
	    public void dragAndDrop(){
	
	    	 Actions action =new Actions(driver);
	    	 action.dragAndDrop(dragAndDropfrom, dragAndDropTo).build().perform();
	    }
	    
	    public boolean isDragAndDropped()
	    {
	    	return postDragAndDrop.isDisplayed();
	    }
	
}
