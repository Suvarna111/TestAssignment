package com.crm.qa.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.crm.qa.base.TestBase;

public class DropDownPage extends TestBase{

	
	@FindBy(xpath = "//li[@class='price_footer']//a[text()='DropDown']")
	WebElement dropDownLink;
	
	@FindBy(tagName = "select")
	WebElement dropDownBox;
	
	
	// Initializing the Page Objects:
		public DropDownPage() {
			PageFactory.initElements(driver, this);
		}

		public void ScrollIntoViewPage(WebElement element)
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView();", element);
		}

	public boolean verifyDropDownLink(){
		ScrollIntoViewPage(dropDownLink);
		if(dropDownLink.isDisplayed())
		{
		return dropDownLink.isDisplayed();
		}
		else
		{
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		}
		return dropDownLink.isDisplayed();
	}
	
	public void clickOnDropDownLink()
	{
		dropDownLink.click();
	}
	
	public boolean verifyDropDownBox(){
		return dropDownBox.isDisplayed();
	}
	
	public void selectItemsByName(String name){
		Select objSelect =new Select(driver.findElement(By.tagName("select")));
		objSelect.selectByVisibleText(name);		
	}
}
